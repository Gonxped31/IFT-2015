
public class Tp2 {
    public static void main(String[] args) {
        String input = args[0];
        String output = args[1];
        Manager manager = new Manager();
        manager.manager(input, output);
    }
}